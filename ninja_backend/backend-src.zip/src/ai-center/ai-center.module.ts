import { Module } from '@nestjs/common';
import { AiCenterController } from './ai-center.controller';
import { AiCenterService } from './ai-center.service';
import { DatabaseModule } from '../database/database.module';
import { SubscriptionsModule } from '../subscriptions/subscriptions.module';
import { PlansModule } from '../plans/plans.module';
import { AiUnitsModule } from '../ai-units/ai-units.module';
import { S3Service } from '../common/aws/s3.service';
import { AiAgentSetupCompleteGuard } from "./guards/ai-agent-setup-complete.guard";
import { PaymentGuard } from "../auth/guards/payment.guard";
import { AestheticWellnessModule } from '../aesthetic-wellness/aesthetic-wellness.module';
import { WorkspaceAiSetupService } from '../aesthetic-wellness/workspace-ai-setup.service';
@Module({
  imports: [DatabaseModule, SubscriptionsModule, PlansModule, AiUnitsModule, AestheticWellnessModule],
  controllers: [AiCenterController],
  providers: [
    PaymentGuard,
    AiCenterService,
    S3Service,
    AiAgentSetupCompleteGuard,
    WorkspaceAiSetupService,
  ],
  exports: [AiCenterService, AiAgentSetupCompleteGuard],
})
export class AiCenterModule {}

import { Module } from '@nestjs/common';
import { CrmController } from './crm.controller';
import { CrmService } from './crm.service';
import { ActivityFeedService } from './activity-feed.service';
import { DashboardAggregationService } from './dashboard-aggregation.service';
import { CrmPropertiesController } from './crm-properties.controller';
import { CrmProjectsController } from './crm-projects.controller';
import { CrmPropertiesService } from './crm-properties.service';
import { CrmProjectsService } from './crm-projects.service';
import { DealsController } from './deals/deals.controller';
import { DealsService } from './deals/deals.service';
import { ContactsController } from './contacts/contacts.controller';
import { ContactsService } from './contacts/contacts.service';
import { DatabaseModule } from '../database/database.module';
import { LeadsModule } from '../leads/leads.module';
import { SubscriptionsModule } from '../subscriptions/subscriptions.module';
import { PlansModule } from '../plans/plans.module';
import { PaymentGuard } from '../auth/guards/payment.guard';

@Module({
  imports: [DatabaseModule, LeadsModule, SubscriptionsModule, PlansModule],
  controllers: [CrmController, CrmPropertiesController, CrmProjectsController, DealsController, ContactsController],
  providers: [
    PaymentGuard,
    CrmService,
    ActivityFeedService,
    DashboardAggregationService,
    CrmPropertiesService,
    CrmProjectsService,
    DealsService,
    ContactsService,
  ],
  exports: [
    CrmService,
    ActivityFeedService,
    DashboardAggregationService,
    CrmPropertiesService,
    CrmProjectsService,
    DealsService,
    ContactsService,
  ],
})
export class CrmModule {}

import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
  Query,
  UseGuards,
  Req,
} from "@nestjs/common";

import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
  ApiQuery,
} from "@nestjs/swagger";

import { ContactsService } from "./contacts.service";
import { CreateContactDto } from "./dto/create-contact.dto";
import { UpdateContactDto } from "./dto/update-contact.dto";
import { CreateContactActivityDto } from "./dto/create-contact-activity.dto";

import { JwtAuthGuard } from "../../auth/guards/jwt-auth.guard";
import { PaymentGuard } from "../../auth/guards/payment.guard";
import { VaRestrictionGuard } from "../../auth/guards/va-restriction.guard";
import { CrmAccessGuard } from "../../subscriptions/guards/crm-access.guard";
import { FeatureAccessGuard } from "../../plans/feature-access.guard";
import { RequireFeature } from "../../plans/require-feature.decorator";

import { CurrentUser } from "../../auth/decorators/current-user.decorator";

@ApiTags("contacts")
@ApiBearerAuth("JWT-auth")
@Controller("contacts")
@UseGuards(JwtAuthGuard, VaRestrictionGuard, CrmAccessGuard, PaymentGuard)
export class ContactsController {
  constructor(private readonly contactsService: ContactsService) {}

  // ======================================================
  // STATS
  // ======================================================

  @Get("stats")
  async getStats(@CurrentUser() user: any) {
    return this.contactsService.getStats(
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }


  @Get("filter-options")
  async getFilterOptions(@CurrentUser() user: any) {
    return this.contactsService.getFilterOptions(
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // AI INSIGHTS
  // ======================================================

  @Get("ai-insights")
  @UseGuards(FeatureAccessGuard)
  @RequireFeature("advancedAiAgent")
  async getAiInsights(@CurrentUser() user: any) {
    return this.contactsService.getAiInsights(
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // AI REVIEW
  // ======================================================

  @Post("ai-review")
  @UseGuards(FeatureAccessGuard)
  @RequireFeature("advancedAiAgent")
  async runAiReview(@CurrentUser() user: any) {
    return this.contactsService.runAiReview(
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }


  @Post("import/batch")
  async importBatch(
    @Body()
    body: {
      importId?: string;
      fileName?: string;
      rows: Record<string, any>[];
      duplicateStrategy?: "skip" | "update";
      isFirstBatch?: boolean;
      isLastBatch?: boolean;
    },
    @CurrentUser() user: any,
  ) {
    return this.contactsService.importBatch(
      body,
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // ACTIVITY
  // ======================================================

  @Get("activity")
  async getActivity(@CurrentUser() user: any) {
    return this.contactsService.getActivity(
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // CREATE
  // ======================================================

  @Post()
  async create(@Body() dto: CreateContactDto, @CurrentUser() user: any) {
    return this.contactsService.create(
      dto,
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // LIST
  // ======================================================

  @Get()
  async findAll(
    @CurrentUser() user: any,

    @Query("search") search?: string,
    @Query("type") type?: string,
    @Query("status") status?: string,
    @Query("source") source?: string,
    @Query("assignedTo") assignedTo?: string,
    @Query("lastActivity") lastActivity?: string,
    @Query("tag") tag?: string,

    @Query("page") page?: string,
    @Query("limit") limit?: string,
  ) {
    return this.contactsService.findAll(
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
      {
        search,
        type,
        status,
        source,
        assignedTo,
        lastActivity,
        tag,
        page: Number(page || 1),
        limit: Number(limit || 20),
      },
    );
  }

  // ======================================================
  // SINGLE
  // ======================================================

  @Get(":id")
  async findOne(@Param("id") id: string, @CurrentUser() user: any) {
    return this.contactsService.findOne(
      id,
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // UPDATE
  // ======================================================

  @Put(":id")
  async update(
    @Param("id") id: string,
    @Body() dto: UpdateContactDto,
    @CurrentUser() user: any,
  ) {
    return this.contactsService.update(
      id,
      dto,
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // MESSAGE
  // ======================================================

  @Post(":id/message")
  async messageContact(
    @Param("id") id: string,
    @Body()
    body: {
      channel: string;
      message: string;
    },
    @CurrentUser() user: any,
  ) {
    return this.contactsService.messageContact(
      id,
      body,
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );
  }

  // ======================================================
  // DELETE
  // ======================================================

  @Delete(":id")
  async remove(@Param("id") id: string, @CurrentUser() user: any) {
    await this.contactsService.remove(
      id,
      user.id,
      user.teamId ?? null,
      user.role ?? "owner",
    );

    return {
      success: true,
    };
  }

  @Get(":id/activities")
  getActivities(@Param("id") id: string, @Req() req) {
    return this.contactsService.getActivities(id, req.user);
  }

  @Get(":id/linked-lead")
  getLinkedLead(@Param("id") id: string, @Req() req: any) {
    return this.contactsService.getLinkedLead(id, req.user);
  }

  @Post(":id/activities")
  createActivity(
    @Param("id") id: string,
    @Body() dto: CreateContactActivityDto,
    @Req() req,
  ) {
    return this.contactsService.addActivity(id, req.user, dto);
  }
}
